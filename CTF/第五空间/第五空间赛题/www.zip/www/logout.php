﻿<?php
session_start();
require_once('common/Db.php');
require_once('common/Function.php');
unset($_SESSION['adminuser']);
Tz('index');


?>
